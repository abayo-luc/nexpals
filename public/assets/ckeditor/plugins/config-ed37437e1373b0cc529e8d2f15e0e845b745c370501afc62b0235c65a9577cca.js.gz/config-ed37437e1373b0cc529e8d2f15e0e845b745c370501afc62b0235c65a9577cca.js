CKEDITOR.editorConfig = function( config )
{
  f.cktext_area :extraPlugins => 'image2'
};
